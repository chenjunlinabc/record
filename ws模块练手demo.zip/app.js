const ws = new WebSocket('ws://localhost:8080')
ws.onopen = () =>{
    console.log("连接中")
    ws.send('hallo word') // 向服务端发送数据
    const obj = {
        name: 'root',
        age: 20,
        pass: '123456',
        email: 'a@cjlio.com',
        key: 'hallo word'
    }
    const blob = new Blob([JSON.stringify(obj, null, 2)], {type : 'application/json'})
    ws.send(blob) // 发送Blob数据
}
ws.onerror = () =>{
    console.log('连接失败')
}
ws.onmessage = (message) =>{
    console.log('连接成功，正在获取数据')
    console.log(message.data) 
}
ws.onclose = () =>{
    console.log('连接已关闭')
}
