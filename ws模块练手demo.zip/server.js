    const WebSocket = require('ws') // 导入模块
    const WebSocketServer = WebSocket.Server
    const wsmain =new WebSocketServer({
        port: 8080
    })
    wsmain.on('connection',function(ws){  
        console.log('客户端已连接')
        ws.on('message',function(message){
            console.log(`客户端发送的数据:${message}`)
            ws.send('欢迎连接该ws服务端')
            ws.send(message)
        })
        
    })